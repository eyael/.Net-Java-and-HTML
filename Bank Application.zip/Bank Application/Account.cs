﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BankApplication
{
    public class Account
    {
        public string AccountNumber { get; set; }
        public string Balance { get; set; }
        public string AccountType { get; set; }
    }
}
